//
//  MovieGridCell.swift
//  flix2
//
//  Created by Wiliam Kwon on 2/17/19.
//  Copyright © 2019 Wiliam Kwon. All rights reserved.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
}
